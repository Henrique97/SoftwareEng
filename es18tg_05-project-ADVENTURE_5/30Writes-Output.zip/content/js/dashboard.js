/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 84.69514724180839, "KoPercent": 15.304852758191622};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8048527581916217, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Clean Activities Database"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Tax Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Offer"], "isController": false}, {"data": [1.0, 500, 1500, "Create Room"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Banks Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Provider"], "isController": false}, {"data": [1.0, 500, 1500, "Create Bank"], "isController": false}, {"data": [1.0, 500, 1500, "Create TaxPayers"], "isController": false}, {"data": [1.0, 500, 1500, "Create Account"], "isController": false}, {"data": [1.0, 500, 1500, "Create Broker"], "isController": false}, {"data": [0.8025, 500, 1500, "Read Adventures"], "isController": false}, {"data": [1.0, 500, 1500, "Create Adventures"], "isController": false}, {"data": [1.0, 500, 1500, "Deposit Account"], "isController": false}, {"data": [1.0, 500, 1500, "Read Accounts"], "isController": false}, {"data": [0.9875, 500, 1500, "Read Banks"], "isController": false}, {"data": [0.5925, 500, 1500, "Read Offers"], "isController": false}, {"data": [0.63125, 500, 1500, "Read Activities"], "isController": false}, {"data": [1.0, 500, 1500, "Create Client"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Hotels Database"], "isController": false}, {"data": [1.0, 500, 1500, "Read Clients"], "isController": false}, {"data": [1.0, 500, 1500, "Create Car"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Brokers Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Hotel"], "isController": false}, {"data": [0.5454166666666667, 500, 1500, "Process Adventure"], "isController": false}, {"data": [1.0, 500, 1500, "Create Activity"], "isController": false}, {"data": [1.0, 500, 1500, "Create ItemType"], "isController": false}, {"data": [1.0, 500, 1500, "Create RentACar"], "isController": false}, {"data": [0.9975, 500, 1500, "Read Rooms"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Car Database"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4822, 738, 15.304852758191622, 884.6283699709667, 2, 76516, 534.0, 1031.2499999999973, 30277.869999999275, 52.444966501348645, 424.867023762426, 12.528282330820934], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["Clean Activities Database", 1, 0, 0.0, 68.0, 68, 68, 68.0, 68.0, 68.0, 14.705882352941176, 25.548598345588232, 3.97805606617647], "isController": false}, {"data": ["Clean Tax Database", 1, 0, 0.0, 24.0, 24, 24, 24.0, 24.0, 24.0, 41.666666666666664, 29.78515625, 10.6201171875], "isController": false}, {"data": ["Create Offer", 100, 0, 0.0, 17.44999999999999, 12, 37, 23.0, 25.94999999999999, 36.91999999999996, 56.14823133071308, 700.5292409460977, 23.687535092644584], "isController": false}, {"data": ["Create Room", 100, 0, 0.0, 14.73, 10, 27, 18.0, 19.0, 26.949999999999974, 66.40106241699867, 531.0347153054449, 23.79284943559097], "isController": false}, {"data": ["Clean Banks Database", 1, 0, 0.0, 153.0, 153, 153, 153.0, 153.0, 153.0, 6.5359477124183005, 9.127348856209151, 1.7105800653594772], "isController": false}, {"data": ["Create Provider", 1, 0, 0.0, 185.0, 185, 185, 185.0, 185.0, 185.0, 5.405405405405405, 10.314611486486486, 5.627111486486487], "isController": false}, {"data": ["Create Bank", 1, 0, 0.0, 19.0, 19, 19, 19.0, 19.0, 19.0, 52.63157894736842, 79.40995065789474, 17.526726973684212], "isController": false}, {"data": ["Create TaxPayers", 6, 0, 0.0, 13.0, 11, 17, 17.0, 17.0, 17.0, 76.92307692307693, 259.0519831730769, 29.196714743589745], "isController": false}, {"data": ["Create Account", 100, 0, 0.0, 16.570000000000004, 10, 128, 20.0, 22.0, 127.17999999999958, 30.23888720895071, 269.41578706153615, 10.719449274266708], "isController": false}, {"data": ["Create Broker", 100, 0, 0.0, 13.989999999999997, 9, 31, 17.0, 19.0, 30.95999999999998, 23.929169657812874, 254.2990716229959, 9.509040739411342], "isController": false}, {"data": ["Read Adventures", 400, 79, 19.75, 75.78000000000006, 2, 695, 251.0, 378.84999999999997, 581.9100000000001, 5.141454260337537, 11.908893430506819, 0.794339620367871], "isController": false}, {"data": ["Create Adventures", 100, 0, 0.0, 15.539999999999997, 11, 54, 20.0, 22.0, 53.969999999999985, 23.998080153587715, 65.6481075263979, 11.572980411567075], "isController": false}, {"data": ["Deposit Account", 100, 0, 0.0, 15.75, 12, 29, 18.900000000000006, 20.0, 29.0, 30.184123151222458, 51.79554265393902, 12.113148015393902], "isController": false}, {"data": ["Read Accounts", 400, 0, 0.0, 15.707500000000005, 8, 112, 19.0, 27.899999999999977, 50.950000000000045, 5.1476738948587615, 83.05330707885594, 0.7389727173283572], "isController": false}, {"data": ["Read Banks", 400, 5, 1.25, 10.822500000000007, 2, 108, 23.900000000000034, 48.94999999999999, 88.99000000000001, 5.142313526855733, 6.918709162799218, 0.6099592351130023], "isController": false}, {"data": ["Read Offers", 400, 163, 40.75, 242.57999999999984, 8, 1075, 573.5000000000002, 739.75, 931.98, 5.219274781769073, 73.27929328165165, 0.8155116846514178], "isController": false}, {"data": ["Read Activities", 400, 147, 36.75, 242.88500000000002, 2, 1151, 603.6000000000001, 825.6499999999999, 990.8500000000001, 5.187529179851637, 8.969764810395809, 0.7180345870402551], "isController": false}, {"data": ["Create Client", 101, 0, 0.0, 11.920792079207922, 9, 36, 14.0, 14.899999999999991, 35.76000000000005, 9.117992236165026, 18.43558161054437, 3.713705764196082], "isController": false}, {"data": ["Clean Hotels Database", 1, 0, 0.0, 67.0, 67, 67, 67.0, 67.0, 67.0, 14.925373134328359, 29.500932835820894, 3.935401119402985], "isController": false}, {"data": ["Read Clients", 400, 0, 0.0, 18.642500000000005, 11, 147, 25.0, 30.0, 56.940000000000055, 5.143239212055753, 131.61670943993337, 0.6830864578511546], "isController": false}, {"data": ["Create Car", 100, 0, 0.0, 19.55, 13, 40, 24.900000000000006, 27.94999999999999, 39.969999999999985, 50.45408678102926, 711.334136131433, 21.531675706357216], "isController": false}, {"data": ["Clean Brokers Database", 1, 0, 0.0, 246.0, 246, 246, 246.0, 246.0, 246.0, 4.065040650406504, 7.50682799796748, 1.0797764227642277], "isController": false}, {"data": ["Create Hotel", 1, 0, 0.0, 24.0, 24, 24, 24.0, 24.0, 24.0, 41.666666666666664, 87.19889322916667, 16.398111979166668], "isController": false}, {"data": ["Process Adventure", 1200, 343, 28.583333333333332, 3334.620833333336, 4, 76516, 9323.8, 23324.00000000002, 59028.590000000026, 15.378306335862211, 36.756617577564334, 5.476857150752256], "isController": false}, {"data": ["Create Activity", 1, 0, 0.0, 44.0, 44, 44, 44.0, 44.0, 44.0, 22.727272727272727, 47.31889204545455, 9.077592329545455], "isController": false}, {"data": ["Create ItemType", 4, 0, 0.0, 11.25, 9, 18, 18.0, 18.0, 18.0, 88.88888888888889, 146.13715277777777, 29.752604166666668], "isController": false}, {"data": ["Create RentACar", 1, 0, 0.0, 25.0, 25, 25, 25.0, 25.0, 25.0, 40.0, 81.2109375, 14.2578125], "isController": false}, {"data": ["Read Rooms", 400, 1, 0.25, 19.840000000000018, 8, 129, 33.0, 50.0, 95.86000000000013, 5.1790662143615505, 72.86335448523319, 0.6962151950565814], "isController": false}, {"data": ["Clean Car Database", 1, 0, 0.0, 90.0, 90, 90, 90.0, 90.0, 90.0, 11.11111111111111, 19.661458333333336, 2.994791666666667], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500", 712, 96.4769647696477, 14.765657403566985], "isController": false}, {"data": ["Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 26, 3.5230352303523036, 0.5391953546246371], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4822, 738, "500", 712, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 26, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Read Adventures", 400, 79, "500", 77, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 2, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Read Banks", 400, 5, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Read Offers", 400, 163, "500", 163, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Read Activities", 400, 147, "500", 138, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 9, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Process Adventure", 1200, 343, "500", 334, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 9, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Read Rooms", 400, 1, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
