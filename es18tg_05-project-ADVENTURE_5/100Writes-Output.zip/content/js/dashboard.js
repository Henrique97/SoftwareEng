/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.78082191780823, "KoPercent": 4.219178082191781};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7890410958904109, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Create Buyer"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Activities Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Client"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Hotels Database"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Tax Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Itemtype"], "isController": false}, {"data": [1.0, 500, 1500, "Create Car"], "isController": false}, {"data": [1.0, 500, 1500, "Create Offer"], "isController": false}, {"data": [1.0, 500, 1500, "Create Room"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Banks Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Provider"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Brokers Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Bank"], "isController": false}, {"data": [1.0, 500, 1500, "Create Hotel"], "isController": false}, {"data": [0.23, 500, 1500, "Process Adventure"], "isController": false}, {"data": [1.0, 500, 1500, "Create Account"], "isController": false}, {"data": [1.0, 500, 1500, "Create Broker"], "isController": false}, {"data": [1.0, 500, 1500, "Create Activity"], "isController": false}, {"data": [1.0, 500, 1500, "Create RentACar"], "isController": false}, {"data": [1.0, 500, 1500, "Create Adventures"], "isController": false}, {"data": [1.0, 500, 1500, "Deposit Account"], "isController": false}, {"data": [1.0, 500, 1500, "Create Seller"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Car Database"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1825, 77, 4.219178082191781, 10059.990684931505, 8, 415055, 4888.600000000004, 42436.8999999999, 283323.24000000005, 3.9134537033066, 38.18352464470665, 1.5237068012340782], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["Create Buyer", 100, 0, 0.0, 63.74999999999999, 27, 111, 85.9, 92.94999999999999, 110.99, 7.77363184079602, 357.6564504139459, 2.869487401857898], "isController": false}, {"data": ["Clean Activities Database", 1, 0, 0.0, 105.0, 105, 105, 105.0, 105.0, 105.0, 9.523809523809526, 16.54575892857143, 2.576264880952381], "isController": false}, {"data": ["Create Client", 204, 0, 0.0, 21.9656862745098, 8, 65, 33.0, 39.75, 56.64999999999992, 5.697528278173439, 29.46706771051529, 2.1472101487222455], "isController": false}, {"data": ["Clean Hotels Database", 1, 0, 0.0, 63.0, 63, 63, 63.0, 63.0, 63.0, 15.873015873015872, 31.374007936507937, 4.185267857142857], "isController": false}, {"data": ["Clean Tax Database", 1, 0, 0.0, 62.0, 62, 62, 62.0, 62.0, 62.0, 16.129032258064516, 11.35647681451613, 4.11101310483871], "isController": false}, {"data": ["Create Itemtype", 4, 0, 0.0, 21.25, 18, 24, 24.0, 24.0, 24.0, 47.05882352941176, 77.36672794117646, 15.751378676470587], "isController": false}, {"data": ["Create Car", 100, 0, 0.0, 34.41999999999999, 19, 80, 43.0, 44.0, 79.84999999999992, 28.661507595299515, 404.0883513363428, 12.231522284322155], "isController": false}, {"data": ["Create Offer", 100, 0, 0.0, 37.4, 19, 89, 52.80000000000001, 65.89999999999998, 88.85999999999993, 26.143790849673202, 326.17621527777777, 11.029411764705882], "isController": false}, {"data": ["Create Room", 100, 0, 0.0, 35.870000000000005, 17, 107, 57.80000000000001, 72.74999999999994, 106.8099999999999, 27.609055770292656, 220.80018808669243, 9.892885491441193], "isController": false}, {"data": ["Clean Banks Database", 1, 0, 0.0, 175.0, 175, 175, 175.0, 175.0, 175.0, 5.714285714285714, 7.979910714285714, 1.4955357142857144], "isController": false}, {"data": ["Create Provider", 1, 0, 0.0, 139.0, 139, 139, 139.0, 139.0, 139.0, 7.194244604316547, 13.728080035971221, 2.6627135791366903], "isController": false}, {"data": ["Clean Brokers Database", 1, 0, 0.0, 85.0, 85, 85, 85.0, 85.0, 85.0, 11.76470588235294, 21.72564338235294, 3.1249999999999996], "isController": false}, {"data": ["Create Bank", 1, 0, 0.0, 21.0, 21, 21, 21.0, 21.0, 21.0, 47.61904761904761, 71.84709821428571, 15.85751488095238], "isController": false}, {"data": ["Create Hotel", 1, 0, 0.0, 29.0, 29, 29, 29.0, 29.0, 29.0, 34.48275862068965, 72.16460129310344, 13.570851293103448], "isController": false}, {"data": ["Process Adventure", 500, 77, 15.4, 36639.282, 20, 415055, 138426.70000000007, 254570.14999999988, 395167.22000000003, 1.1739238639938767, 2.9918481442905036, 0.4389305913113199], "isController": false}, {"data": ["Create Account", 203, 0, 0.0, 15.650246305418722, 8, 36, 22.0, 25.799999999999983, 32.0, 30.48048048048048, 159.9515531156156, 11.577104448198199], "isController": false}, {"data": ["Create Broker", 100, 0, 0.0, 21.909999999999993, 11, 72, 29.0, 38.64999999999992, 71.73999999999987, 16.36929120969062, 173.95904735840563, 6.522139466361106], "isController": false}, {"data": ["Create Activity", 1, 0, 0.0, 29.0, 29, 29, 29.0, 29.0, 29.0, 34.48275862068965, 71.79418103448276, 13.772898706896552], "isController": false}, {"data": ["Create RentACar", 1, 0, 0.0, 28.0, 28, 28, 28.0, 28.0, 28.0, 35.714285714285715, 72.509765625, 12.730189732142858], "isController": false}, {"data": ["Create Adventures", 100, 0, 0.0, 21.210000000000004, 10, 67, 28.80000000000001, 40.74999999999994, 66.90999999999995, 16.345210853220006, 44.753634255475646, 7.884010297482837], "isController": false}, {"data": ["Deposit Account", 203, 0, 0.0, 16.546798029556665, 9, 38, 24.0, 26.0, 35.880000000000024, 30.563083408611863, 52.17037413429689, 12.384494504667268], "isController": false}, {"data": ["Create Seller", 100, 0, 0.0, 65.01000000000003, 23, 135, 86.9, 95.79999999999995, 134.8499999999999, 7.749535027898326, 359.9723347653828, 2.8602898083927464], "isController": false}, {"data": ["Clean Car Database", 1, 0, 0.0, 47.0, 47, 47, 47.0, 47.0, 47.0, 21.27659574468085, 37.649601063829785, 5.73470744680851], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500", 77, 100.0, 4.219178082191781], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1825, 77, "500", 77, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Process Adventure", 500, 77, "500", 77, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
