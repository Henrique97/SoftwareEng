/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6184971098265896, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Create Buyer"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Activities Database"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Tax Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Itemtype"], "isController": false}, {"data": [0.8, 500, 1500, "Read Seller"], "isController": false}, {"data": [0.2, 500, 1500, "Read Providers"], "isController": false}, {"data": [1.0, 500, 1500, "Create Offer"], "isController": false}, {"data": [1.0, 500, 1500, "Create Room"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Banks Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Provider"], "isController": false}, {"data": [1.0, 500, 1500, "Create Bank"], "isController": false}, {"data": [1.0, 500, 1500, "Create Account"], "isController": false}, {"data": [1.0, 500, 1500, "Create Broker"], "isController": false}, {"data": [0.81675, 500, 1500, "Read Buyer"], "isController": false}, {"data": [0.71925, 500, 1500, "Read Adventures"], "isController": false}, {"data": [0.80175, 500, 1500, "Read Types"], "isController": false}, {"data": [1.0, 500, 1500, "Create Adventures"], "isController": false}, {"data": [1.0, 500, 1500, "Deposit Account"], "isController": false}, {"data": [1.0, 500, 1500, "Create Seller"], "isController": false}, {"data": [0.5015, 500, 1500, "Read Accounts"], "isController": false}, {"data": [0.88425, 500, 1500, "Read Hotels"], "isController": false}, {"data": [0.5065, 500, 1500, "Read Banks"], "isController": false}, {"data": [0.26275, 500, 1500, "Read Offers"], "isController": false}, {"data": [0.25175, 500, 1500, "Read Activities"], "isController": false}, {"data": [1.0, 500, 1500, "Create Client"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Hotels Database"], "isController": false}, {"data": [0.533, 500, 1500, "Read Clients"], "isController": false}, {"data": [1.0, 500, 1500, "Create Car"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Brokers Database"], "isController": false}, {"data": [1.0, 500, 1500, "Create Hotel"], "isController": false}, {"data": [1.0, 500, 1500, "Create Activity"], "isController": false}, {"data": [1.0, 500, 1500, "Create RentACar"], "isController": false}, {"data": [0.8975, 500, 1500, "Read Rooms"], "isController": false}, {"data": [0.71, 500, 1500, "Read Brokers"], "isController": false}, {"data": [1.0, 500, 1500, "Clean Car Database"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 26815, 0, 0.0, 1083.6888681708065, 3, 6475, 2600.0, 3307.0, 4666.960000000006, 313.47907411737197, 2895.743447875263, 44.12416248977087], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["Create Buyer", 1, 0, 0.0, 24.0, 24, 24, 24.0, 24.0, 24.0, 41.666666666666664, 94.7265625, 15.340169270833332], "isController": false}, {"data": ["Clean Activities Database", 1, 0, 0.0, 88.0, 88, 88, 88.0, 88.0, 88.0, 11.363636363636363, 19.74209872159091, 3.0739524147727275], "isController": false}, {"data": ["Clean Tax Database", 1, 0, 0.0, 29.0, 29, 29, 29.0, 29.0, 29.0, 34.48275862068965, 24.64978448275862, 8.7890625], "isController": false}, {"data": ["Create Itemtype", 1, 0, 0.0, 26.0, 26, 26, 26.0, 26.0, 26.0, 38.46153846153847, 59.983473557692314, 12.845552884615385], "isController": false}, {"data": ["Read Seller", 2000, 0, 0.0, 424.15749999999986, 5, 2285, 1324.3000000000006, 1907.749999999999, 2132.91, 31.88978888959755, 80.87673998660628, 3.986223611199694], "isController": false}, {"data": ["Read Providers", 2000, 0, 0.0, 2215.0770000000025, 4, 5571, 3957.5000000000005, 4414.9, 5471.95, 31.56466020643288, 54.621658091600644, 3.914757662321265], "isController": false}, {"data": ["Create Offer", 100, 0, 0.0, 33.87999999999999, 25, 64, 39.900000000000006, 44.94999999999999, 63.83999999999992, 29.086678301337987, 362.8977830497382, 12.270942408376962], "isController": false}, {"data": ["Create Room", 100, 0, 0.0, 29.429999999999996, 19, 47, 36.0, 40.94999999999999, 46.97999999999999, 33.738191632928476, 269.8172338900135, 12.089079369095817], "isController": false}, {"data": ["Clean Banks Database", 1, 0, 0.0, 98.0, 98, 98, 98.0, 98.0, 98.0, 10.204081632653061, 14.24984056122449, 2.670599489795918], "isController": false}, {"data": ["Create Provider", 1, 0, 0.0, 103.0, 103, 103, 103.0, 103.0, 103.0, 9.70873786407767, 18.526243932038835, 3.5933707524271847], "isController": false}, {"data": ["Create Bank", 1, 0, 0.0, 19.0, 19, 19, 19.0, 19.0, 19.0, 52.63157894736842, 79.40995065789474, 17.526726973684212], "isController": false}, {"data": ["Create Account", 100, 0, 0.0, 25.379999999999995, 16, 87, 32.0, 40.69999999999993, 86.71999999999986, 19.864918553833927, 176.67749925506556, 7.274750446960668], "isController": false}, {"data": ["Create Broker", 100, 0, 0.0, 20.139999999999993, 14, 50, 23.0, 26.94999999999999, 49.85999999999993, 16.62510390689942, 176.67760936201165, 6.606530548628429], "isController": false}, {"data": ["Read Buyer", 2000, 0, 0.0, 397.93900000000025, 5, 2204, 1247.6000000000004, 1849.8999999999996, 2089.95, 31.878606267333993, 80.84837937135389, 3.984825783416749], "isController": false}, {"data": ["Read Adventures", 2000, 0, 0.0, 1315.1595000000023, 10, 6404, 5228.9, 5488.95, 6085.99, 31.425294219317127, 601.7145935138193, 4.756758402338042], "isController": false}, {"data": ["Read Types", 2000, 0, 0.0, 422.12949999999904, 3, 2460, 1301.6000000000004, 1861.8499999999995, 2134.9700000000003, 31.855249745158, 44.01872889589704, 3.9507975758154945], "isController": false}, {"data": ["Create Adventures", 100, 0, 0.0, 21.790000000000003, 15, 50, 26.0, 31.94999999999999, 49.889999999999944, 16.650016650016653, 45.54706361346986, 8.027454316516817], "isController": false}, {"data": ["Deposit Account", 100, 0, 0.0, 24.109999999999992, 17, 53, 29.0, 32.0, 52.909999999999954, 19.849146486701073, 33.75072108227471, 7.96563306371576], "isController": false}, {"data": ["Create Seller", 1, 0, 0.0, 18.0, 18, 18, 18.0, 18.0, 18.0, 55.55555555555555, 150.8246527777778, 20.5078125], "isController": false}, {"data": ["Read Accounts", 2000, 0, 0.0, 1365.1775000000014, 12, 4900, 3360.5000000000005, 3909.7999999999993, 4581.88, 31.46039136726861, 507.3602568740955, 4.5162866513559425], "isController": false}, {"data": ["Read Hotels", 2000, 0, 0.0, 275.1834999999996, 4, 1843, 662.9000000000001, 845.8499999999995, 1507.98, 31.47821707378494, 60.37423665323596, 3.8118153487786453], "isController": false}, {"data": ["Read Banks", 2000, 0, 0.0, 1333.8409999999994, 3, 4800, 3297.9, 3888.449999999998, 4411.71, 31.431714600031434, 41.960111189690394, 3.775489156058463], "isController": false}, {"data": ["Read Offers", 2000, 0, 0.0, 2005.806500000001, 11, 5594, 3686.8, 4421.9, 5474.99, 31.778819416858667, 721.8819516167474, 4.965440533884166], "isController": false}, {"data": ["Read Activities", 2000, 0, 0.0, 2003.5360000000042, 4, 5586, 3600.7000000000003, 4280.0, 5532.99, 31.67513976655422, 59.76208010642847, 4.485249283349963], "isController": false}, {"data": ["Create Client", 101, 0, 0.0, 17.801980198019812, 12, 49, 21.799999999999997, 23.799999999999983, 48.84000000000003, 5.790288367826635, 11.706433096371036, 2.3570074671788106], "isController": false}, {"data": ["Clean Hotels Database", 1, 0, 0.0, 52.0, 52, 52, 52.0, 52.0, 52.0, 19.230769230769234, 38.01081730769231, 5.070612980769231], "isController": false}, {"data": ["Read Clients", 2000, 0, 0.0, 1290.3214999999975, 9, 4799, 3302.9, 3857.0, 4630.89, 31.429738818870415, 513.3114765691297, 4.174262186881227], "isController": false}, {"data": ["Create Car", 100, 0, 0.0, 31.97, 24, 63, 39.80000000000001, 45.0, 62.89999999999995, 30.96934035305048, 436.6256605179622, 13.2164079436358], "isController": false}, {"data": ["Clean Brokers Database", 1, 0, 0.0, 173.0, 173, 173, 173.0, 173.0, 173.0, 5.780346820809248, 10.674449060693643, 1.5354046242774568], "isController": false}, {"data": ["Create Hotel", 1, 0, 0.0, 24.0, 24, 24, 24.0, 24.0, 24.0, 41.666666666666664, 87.19889322916667, 16.398111979166668], "isController": false}, {"data": ["Create Activity", 1, 0, 0.0, 24.0, 24, 24, 24.0, 24.0, 24.0, 41.666666666666664, 86.75130208333333, 16.642252604166668], "isController": false}, {"data": ["Create RentACar", 1, 0, 0.0, 30.0, 30, 30, 30.0, 30.0, 30.0, 33.333333333333336, 67.67578125, 11.881510416666668], "isController": false}, {"data": ["Read Rooms", 2000, 0, 0.0, 254.64250000000064, 10, 1857, 639.8000000000002, 890.7999999999993, 1443.95, 31.504497266984863, 444.1703389096294, 4.245723264496007], "isController": false}, {"data": ["Read Brokers", 2000, 0, 0.0, 1215.970000000004, 12, 6475, 4803.300000000001, 5303.799999999999, 6382.0, 31.42331924521187, 599.0683967822521, 3.8358544000502772], "isController": false}, {"data": ["Clean Car Database", 1, 0, 0.0, 59.0, 59, 59, 59.0, 59.0, 59.0, 16.949152542372882, 29.992055084745765, 4.568326271186441], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 26815, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
